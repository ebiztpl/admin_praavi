<?php

namespace App\Contracts;

interface HasColor
{
    public function color(): string;
}
