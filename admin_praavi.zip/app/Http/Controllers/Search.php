<?php

namespace App\Http\Controllers;

class Search extends Controller
{
    /**
     * Search items
     */
    public function __invoke()
    {
    }
}
